package com.example.project;

public class user {
    public String name;
    public String email;

    public user() {}

    public user(String name, String email) {
        this.name = name;
        this.email = email;
    }

}
