package com.example.project.Domain;

public class SliderItems {
    private String url;

    public SliderItems() {
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
